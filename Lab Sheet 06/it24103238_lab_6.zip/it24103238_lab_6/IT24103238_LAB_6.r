##Q1
##part i
##Binomial distribution

##part ii
X<-1-pbinom(46,50,0.85,lower.tail = TRUE)
X
Y<-pbinom(46,50,0.85,lower.tail = FALSE)
Y

#Q2
#part i
#average of customer calls

#part ii
#poison distribution

#part iii
E<-ppois(12,15)
E

